package gui;

import usuari.LlistaUsuaris;

public class ConsultarIntercanvis {
	
	public ConsultarIntercanvis(LlistaUsuaris Lu) {
		
		LlistaUsuaris Lista = null ;
	}

}